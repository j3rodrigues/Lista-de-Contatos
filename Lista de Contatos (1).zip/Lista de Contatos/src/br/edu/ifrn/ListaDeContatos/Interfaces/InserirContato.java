package br.edu.ifrn.ListaDeContatos.Interfaces;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import br.edu.ifrn.ListaDeContatos.Codigos.Agenda;

public class InserirContato extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	private String info = "";
	private JTextField telefone;
	private JTextField nome;
	private JLabel aux1 = new JLabel();
	private Agenda a;
	private JLabel quantidade;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InserirContato frame = new InserirContato();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	private void inserirIc() {
		if (a.getQuantContatos() < a.getTAMANHO()) {
			if(a.inserir(nome.getText(), telefone.getText())) {
				info = "Contato adicionado";
				
			}
		}
		else {
			info = "Nao eh possivel cadastrar, a agenda esta cheia";
		}
	}
	public void info(JLabel info) {
		aux1 = info;
	}
	
	public void q(JLabel quant) {
		quantidade = quant;
	}
	
	public void iContato(Agenda agd) {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 278, 253);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel tituloNome = new JLabel("Nome:");
		tituloNome.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		tituloNome.setForeground(new Color(239, 197, 107));
		tituloNome.setBounds(10, 11, 66, 21);
		contentPane.add(tituloNome);
		
		nome = new JTextField();
		nome.setBackground(new Color(60, 60, 60));
		nome.setForeground(new Color(239, 197, 107));
		nome.setBounds(67, 12, 187, 20);
		contentPane.add(nome);
		nome.setColumns(10);
		
		JLabel tituloTelefone = new JLabel("Telefone:");
		tituloTelefone.setForeground(new Color(239, 197, 107));
		tituloTelefone.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		tituloTelefone.setBounds(10, 90, 66, 21);
		contentPane.add(tituloTelefone);
		
		telefone = new JTextField();
		telefone.setForeground(new Color(239, 197, 107));
		telefone.setColumns(10);
		telefone.setBackground(new Color(60, 60, 60));
		telefone.setBounds(86, 92, 168, 20);
		contentPane.add(telefone);
		
		JButton confirmar = new JButton("Confimar");
		confirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a = agd;
				inserirIc();
				setVisible(false);
				aux1.setText(info);
				quantidade.setText("contatos: " + agd.getQuantContatos());
			}
		});
		confirmar.setFont(new Font("Javanese Text", Font.PLAIN, 15));
		confirmar.setBackground(new Color(239, 197, 107));
		confirmar.setBounds(67, 156, 112, 21);
		contentPane.add(confirmar);
	}
	
	public JTextField getTelefone() {
		return telefone;
	}

	public JTextField getNome() {
		return nome;
	}

	public String getInfo() {
		return info;
	}
	
	public InserirContato() {
		iContato(a);
	}

}
