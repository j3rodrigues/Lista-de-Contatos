package br.edu.ifrn.ListaDeContatos.Interfaces;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import br.edu.ifrn.ListaDeContatos.Codigos.Agenda;
import br.edu.ifrn.ListaDeContatos.Codigos.Pessoa;

public class InserirNome extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InserirNome frame = new InserirNome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private Pessoa busca;
	private boolean remove;
	private JLabel aux = new JLabel();
	private String infoIN;
	private int testeLogico;
	private Agenda a;
	private JLabel quantidade;
	
	public void qIN(JLabel quant) {
		quantidade = quant;
	}
	
	public void info(JLabel info) {
		aux = info;
	}
	
	public void iNome(Agenda agd) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 278, 140);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel tituloNome = new JLabel("Nome:");
		tituloNome.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		tituloNome.setForeground(new Color(239, 197, 107));
		tituloNome.setBounds(10, 11, 66, 21);
		contentPane.add(tituloNome);
		
		JTextField nome = new JTextField();
		nome.setBackground(new Color(60, 60, 60));
		nome.setForeground(new Color(239, 197, 107));
		nome.setBounds(67, 12, 187, 20);
		contentPane.add(nome);
		nome.setColumns(10);
		
		JButton confirmar = new JButton("Confimar");
		confirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a = agd;
				if (testeLogico == 1) {
					if (a.getQuantContatos() > 0) {
						busca = a.buscar(nome.getText());
						if (busca != null) {		
							infoIN = "O nome do contato eh: " + busca.getNome() + " e telefone do contato eh: " + busca.getTelefone();
						}
						else {
							infoIN = "Contato: " + nome.getText() + " nao cadastrado";
						}
					} else {		
						infoIN = "Contato: " + nome.getText() + " nao cadastrado";
					}
				}
				else if (testeLogico == 0) {
					
					if (a.getQuantContatos() > 0) {
						remove = a.remover(nome.getText());
						if (remove == true) {	
							infoIN = "Contato removido";
						}
						else {
							infoIN = "Contato: " + nome.getText() + " nao cadastrado";
						}
					} else {
						infoIN = "Nao foi possivel remover " + nome.getText();
					}
					
					quantidade.setText("contatos: " + agd.getQuantContatos());
				}
				setVisible(false);
				aux.setText(infoIN);
			}
		});
		confirmar.setFont(new Font("Javanese Text", Font.PLAIN, 15));
		confirmar.setBackground(new Color(239, 197, 107));
		confirmar.setBounds(67, 66, 112, 21);
		contentPane.add(confirmar);
	}
	
	public InserirNome() {
		iNome(a);
	}
	
	public void setTesteLogico(int testeLogico) {
		this.testeLogico = testeLogico;
	}
	
	public JLabel getAux() {
		return aux;
	}
	

}
