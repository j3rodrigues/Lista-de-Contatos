package br.edu.ifrn.ListaDeContatos.Interfaces;

import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.ScrollPane;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.awt.event.ActionEvent;

import br.edu.ifrn.ListaDeContatos.Codigos.*;

public class InterfacePrincipal extends JFrame {
	
	Agenda agd = new Agenda(0);
	InserirContato iC = new InserirContato();
	InserirNome iN = new InserirNome();
	
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JLabel titulo;
	private JLabel quantContatos;
	private JLabel info;
	private JButton buscar;
	private JButton inserir;
	private JButton remover;
	private JList exibir;
	private ArrayList<Pessoa> exibicao;
	private int ind;
	private JScrollPane rolagem;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfacePrincipal frame = new InterfacePrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public void principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 455, 347);
		contentPane = new JPanel(new BorderLayout());
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		titulo = new JLabel("Telefone");
		titulo.setBounds(76, 13, 79, 21);
		titulo.setFont(new Font("Times New Roman", Font.BOLD, 18));
		titulo.setHorizontalAlignment(SwingConstants.RIGHT);
		titulo.setForeground(new Color(239, 197, 107));
		contentPane.add(titulo);
		
		info = new JLabel("espere info aq");
		info.setFont(new Font("Times New Roman", Font.BOLD, 15));
		info.setForeground(new Color(239, 197, 107));
		info.setBackground(new Color(0, 0, 0));
		info.setBounds(10, 271, 410, 29);
		contentPane.add(info);
		
		DefaultListModel<String> listModel = new DefaultListModel<>();
		listModel.addElement("A lista aparecerá por aqui");
		exibir = new JList<String>(listModel);
		exibir.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		exibir.setForeground(new Color(239, 197, 107));
		exibir.setBackground(new Color(0, 0, 0));
		exibir.setBounds(10, 82, 414, 168);
		contentPane.add(exibir);
		
		rolagem = new JScrollPane();
		rolagem.setBounds(10, 82, 414, 168);
		contentPane.add(rolagem);
		rolagem.setViewportView(exibir);
		
		JButton exibirB = new JButton("E");
		exibirB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				listModel.removeAllElements();
				if (agd.getQuantContatos() > 0) {
					exibicao = agd.getContatos();
					Collections.sort(exibicao);
					for(int i = 0; i < agd.getTAMANHO(); i++) {
						if(exibicao.get(i) != null) {
							listModel.addElement("contato: "  + exibicao.get(i).getNome() + " - numero: " + exibicao.get(i).getTelefone() + "\n");
						}
					}
				}
				else {
					listModel.addElement("Nenhum contato salvo para exibir");
				}
				
			}
		});
		exibirB.setForeground(new Color(239, 197, 107));
		exibirB.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		exibirB.setBackground(Color.BLACK);
		exibirB.setBounds(298, 45, 49, 23);
		contentPane.add(exibirB);
		
		quantContatos = new JLabel("contatos: ");
		quantContatos.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		quantContatos.setForeground(new Color(239, 197, 107));
		quantContatos.setBounds(73, 50, 195, 21);
		contentPane.add(quantContatos);
		
		inserir = new JButton("+");
		inserir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iC.iContato(agd);
				iC.setVisible(true);
				iC.info(info);
				iC.q(quantContatos);
				agd.exibir();
			}
		});
		
		inserir.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		inserir.setBackground(new Color(0, 0, 0));
		inserir.setForeground(new Color(239, 197, 107));
		inserir.setBounds(298, 12, 49, 23);
		contentPane.add(inserir);
		
		buscar = new JButton("b");
		buscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iN.setTesteLogico(1);
				iN.iNome(agd);
				iN.setVisible(true);
				iN.info(info);
			}
				
		});
		buscar.setBackground(new Color(0, 0, 0));
		buscar.setForeground(new Color(239, 197, 107));
		buscar.setBounds(357, 12, 49, 23);
		contentPane.add(buscar);
			
		remover = new JButton("x");
		remover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				listModel.remove(iN.indice(ind));
				iN.setTesteLogico(0);
				iN.iNome(agd);
				iN.setVisible(true);
				iN.info(info);
				iN.qIN(quantContatos);
			}
		});
		remover.setForeground(new Color(239, 197, 107));
		remover.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		remover.setBackground(Color.BLACK);
		remover.setBounds(357, 45, 49, 23);
		contentPane.add(remover);
		
	}
	
	public InterfacePrincipal() {
		principal();
	}
}
