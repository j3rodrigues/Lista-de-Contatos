package br.edu.ifrn.ListaDeContatos.Codigos;

import java.util.ArrayList;

public class Agenda {
	
	private int quantContatos = 0;
	ArrayList<Pessoa> contatoList;
	
	public Agenda(int quantContatos){
		
		this.quantContatos = quantContatos; 
		
		this.contatoList  = new ArrayList<>();
		
		
	}
	
	public boolean inserir(String nome, String telefone) {
		
		contatoList.add(new Pessoa(nome, telefone));
		quantContatos = quantContatos + 1;
		
		return true;
		
	}
	
	public int buscarPriv(String nome) {
		for (int i = 0; i < contatoList.size(); i++){
			if(contatoList.get(i) != null) {
				if (contatoList.get(i).getNome().equals(nome)) {
					return i;
				}
			}
		}
		return -1;
	}
	
	public Pessoa buscar(String nome) {
		int bpriv = buscarPriv(nome);
		if(bpriv != -1) {
			return contatoList.get(bpriv);
		}
		else {
			return null;
		}
	}
	
	public ArrayList<Pessoa> getContatos() {
		return contatoList;
	}

	public boolean remover(String nome) {
		int buscar;
		buscar = buscarPriv(nome);
		if (buscar != -1) {
			contatoList.remove(buscar);
			quantContatos -= 1;
			return true;
		}
		return false;
	}
	
	public void exibir() {
		for(int i = 0; i < contatoList.size(); i++) {
			if(contatoList.get(i) != null) {
				//na interface vai ficar aparecendo no terminal
				System.out.println("contato: "  + contatoList.get(i).getNome() + " " + contatoList.get(i).getTelefone());
			}
		}
	}
	
	public int getTAMANHO() {
		return contatoList.size();
	}
	public int getQuantContatos() {
		return quantContatos;
	}
}
