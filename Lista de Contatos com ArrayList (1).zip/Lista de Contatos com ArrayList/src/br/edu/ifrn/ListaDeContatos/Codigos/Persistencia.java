package br.edu.ifrn.ListaDeContatos.Codigos;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Persistencia{

	public static void SerializaGrava(String caminhoNome, Object objeto) {
		FileOutputStream arqSaida;
		ObjectOutputStream streamSaida;
		
		try {
			arqSaida = new FileOutputStream(caminhoNome);
			streamSaida = new ObjectOutputStream(arqSaida);
			streamSaida.writeObject(objeto);
			streamSaida.close();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
		
	public static Object IeDeserializa(String caminhoNome) throws IOException, ClassNotFoundException{
		FileInputStream arqEntrada = new FileInputStream(caminhoNome);
		ObjectInputStream streamEntrada = new ObjectInputStream(arqEntrada);
		Object objetoLido = streamEntrada.readObject();
		streamEntrada.close();
		return objetoLido;
		
	}

}

